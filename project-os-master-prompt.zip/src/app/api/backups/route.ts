import { db } from "@/db";
import { backups } from "@/db/schema";
import { desc } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const [backup] = await db.select().from(backups).orderBy(desc(backups.id)).limit(1);
    if (!backup) return Response.json({ error: "No pre-restore backup is available yet." }, { status: 404 });
    return Response.json(backup.data, { headers: { "Content-Disposition": "attachment; filename=project-os-pre-restore.json", "Cache-Control": "no-store" } });
  } catch { return Response.json({ error: "Backup unavailable. Check PostgreSQL." }, { status: 503 }); }
}
